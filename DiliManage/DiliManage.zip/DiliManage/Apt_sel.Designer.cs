﻿namespace DiliManage
{
    partial class Apt_sel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.stu = new System.Windows.Forms.Button();
            this.cou = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.ins = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.ft = new System.Windows.Forms.Button();
            this.re = new System.Windows.Forms.Button();
            this.cour = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.sta = new System.Windows.Forms.Button();
            this.apt = new System.Windows.Forms.Button();
            this.cou.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(266, 326);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(36, 16);
            this.checkBox9.TabIndex = 30;
            this.checkBox9.Text = "하";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(183, 326);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(36, 16);
            this.checkBox10.TabIndex = 31;
            this.checkBox10.Text = "중";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(103, 326);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(36, 16);
            this.checkBox11.TabIndex = 32;
            this.checkBox11.Text = "상";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 327);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 29;
            this.label4.Text = "어학능력";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(103, 216);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(263, 21);
            this.textBox3.TabIndex = 28;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(183, 294);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(48, 16);
            this.checkBox8.TabIndex = 27;
            this.checkBox8.Text = "군필";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(103, 294);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(48, 16);
            this.checkBox7.TabIndex = 27;
            this.checkBox7.Text = "군필";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // stu
            // 
            this.stu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.stu.Dock = System.Windows.Forms.DockStyle.Left;
            this.stu.FlatAppearance.BorderSize = 0;
            this.stu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stu.ForeColor = System.Drawing.Color.White;
            this.stu.Location = new System.Drawing.Point(236, 0);
            this.stu.Name = "stu";
            this.stu.Size = new System.Drawing.Size(118, 99);
            this.stu.TabIndex = 3;
            this.stu.Text = "학생관리";
            this.stu.UseVisualStyleBackColor = false;
            this.stu.Click += new System.EventHandler(this.Stu_Click);
            // 
            // cou
            // 
            this.cou.Controls.Add(this.label9);
            this.cou.Controls.Add(this.textBox6);
            this.cou.Controls.Add(this.label6);
            this.cou.Controls.Add(this.textBox5);
            this.cou.Controls.Add(this.textBox4);
            this.cou.Controls.Add(this.label5);
            this.cou.Controls.Add(this.button9);
            this.cou.Controls.Add(this.button8);
            this.cou.Controls.Add(this.ins);
            this.cou.Controls.Add(this.button7);
            this.cou.Controls.Add(this.checkBox9);
            this.cou.Controls.Add(this.checkBox10);
            this.cou.Controls.Add(this.checkBox11);
            this.cou.Controls.Add(this.label4);
            this.cou.Controls.Add(this.textBox3);
            this.cou.Controls.Add(this.checkBox8);
            this.cou.Controls.Add(this.checkBox7);
            this.cou.Controls.Add(this.label8);
            this.cou.Controls.Add(this.label2);
            this.cou.Controls.Add(this.label3);
            this.cou.Controls.Add(this.label7);
            this.cou.Controls.Add(this.label1);
            this.cou.Controls.Add(this.textBox2);
            this.cou.Controls.Add(this.textBox1);
            this.cou.Dock = System.Windows.Forms.DockStyle.Right;
            this.cou.Location = new System.Drawing.Point(583, 99);
            this.cou.Name = "cou";
            this.cou.Size = new System.Drawing.Size(410, 438);
            this.cou.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(43, 142);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 44;
            this.label9.Text = "계절";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(103, 139);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(263, 21);
            this.textBox6.TabIndex = 43;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 42;
            this.label6.Text = "실습년도";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(103, 65);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(263, 21);
            this.textBox5.TabIndex = 41;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(103, 256);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(263, 21);
            this.textBox4.TabIndex = 40;
            this.textBox4.Text = "소수점 둘째 자리까지 입력이 가능합니다";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 39;
            this.label5.Text = "실습명";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(318, 368);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(71, 38);
            this.button9.TabIndex = 38;
            this.button9.Text = "삭제";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(222, 368);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(71, 38);
            this.button8.TabIndex = 37;
            this.button8.Text = "수정";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // ins
            // 
            this.ins.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.ins.FlatAppearance.BorderSize = 0;
            this.ins.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ins.ForeColor = System.Drawing.Color.White;
            this.ins.Location = new System.Drawing.Point(126, 368);
            this.ins.Name = "ins";
            this.ins.Size = new System.Drawing.Size(71, 38);
            this.ins.TabIndex = 36;
            this.ins.Text = "입력";
            this.ins.UseVisualStyleBackColor = false;
            this.ins.Click += new System.EventHandler(this.Ins_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(27, 368);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(71, 38);
            this.button7.TabIndex = 35;
            this.button7.Text = "조회";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 298);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 12);
            this.label8.TabIndex = 23;
            this.label8.Text = "군/미필";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 259);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 23;
            this.label2.Text = "평균학점";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 23;
            this.label3.Text = "이름";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(227, 12);
            this.label7.TabIndex = 23;
            this.label7.Text = "*조건 미입력시 전체검색으로 진행됩니다";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 23;
            this.label1.Text = "학번";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(103, 176);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(263, 21);
            this.textBox2.TabIndex = 22;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(103, 101);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(263, 21);
            this.textBox1.TabIndex = 22;
            // 
            // ft
            // 
            this.ft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.ft.Dock = System.Windows.Forms.DockStyle.Left;
            this.ft.FlatAppearance.BorderSize = 0;
            this.ft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ft.ForeColor = System.Drawing.Color.White;
            this.ft.Location = new System.Drawing.Point(354, 0);
            this.ft.Name = "ft";
            this.ft.Size = new System.Drawing.Size(118, 99);
            this.ft.TabIndex = 4;
            this.ft.Text = "출결관리";
            this.ft.UseVisualStyleBackColor = false;
            this.ft.Click += new System.EventHandler(this.Ft_Click);
            // 
            // re
            // 
            this.re.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.re.Dock = System.Windows.Forms.DockStyle.Left;
            this.re.FlatAppearance.BorderSize = 0;
            this.re.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.re.ForeColor = System.Drawing.Color.White;
            this.re.Location = new System.Drawing.Point(118, 0);
            this.re.Name = "re";
            this.re.Size = new System.Drawing.Size(118, 99);
            this.re.TabIndex = 2;
            this.re.Text = "신청관리";
            this.re.UseVisualStyleBackColor = false;
            this.re.Click += new System.EventHandler(this.Re_Click);
            // 
            // cour
            // 
            this.cour.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.cour.Dock = System.Windows.Forms.DockStyle.Left;
            this.cour.FlatAppearance.BorderSize = 0;
            this.cour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cour.ForeColor = System.Drawing.Color.White;
            this.cour.Location = new System.Drawing.Point(0, 0);
            this.cour.Name = "cour";
            this.cour.Size = new System.Drawing.Size(118, 99);
            this.cour.TabIndex = 1;
            this.cour.Text = "코스관리";
            this.cour.UseVisualStyleBackColor = false;
            this.cour.Click += new System.EventHandler(this.Cour_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.cou);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(993, 537);
            this.panel1.TabIndex = 3;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.dataGridView1);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 99);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(583, 438);
            this.panel7.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(583, 438);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "test";
            this.Column1.Name = "Column1";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(993, 99);
            this.panel2.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.panel5.Controls.Add(this.sta);
            this.panel5.Controls.Add(this.apt);
            this.panel5.Controls.Add(this.ft);
            this.panel5.Controls.Add(this.stu);
            this.panel5.Controls.Add(this.re);
            this.panel5.Controls.Add(this.cour);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(993, 99);
            this.panel5.TabIndex = 2;
            // 
            // sta
            // 
            this.sta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.sta.Dock = System.Windows.Forms.DockStyle.Left;
            this.sta.FlatAppearance.BorderSize = 0;
            this.sta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sta.ForeColor = System.Drawing.Color.White;
            this.sta.Location = new System.Drawing.Point(590, 0);
            this.sta.Name = "sta";
            this.sta.Size = new System.Drawing.Size(118, 99);
            this.sta.TabIndex = 8;
            this.sta.Text = "통계";
            this.sta.UseVisualStyleBackColor = false;
            this.sta.Click += new System.EventHandler(this.Sta_Click);
            // 
            // apt
            // 
            this.apt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(84)))), ((int)(((byte)(100)))));
            this.apt.Dock = System.Windows.Forms.DockStyle.Left;
            this.apt.FlatAppearance.BorderSize = 0;
            this.apt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.apt.ForeColor = System.Drawing.Color.White;
            this.apt.Location = new System.Drawing.Point(472, 0);
            this.apt.Name = "apt";
            this.apt.Size = new System.Drawing.Size(118, 99);
            this.apt.TabIndex = 5;
            this.apt.Text = "실습생관리";
            this.apt.UseVisualStyleBackColor = false;
            this.apt.Click += new System.EventHandler(this.Apt_Click);
            // 
            // Apt_sel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(993, 537);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Apt_sel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StudentInfromation";
            this.cou.ResumeLayout(false);
            this.cou.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Button stu;
        private System.Windows.Forms.Panel cou;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button ft;
        private System.Windows.Forms.Button re;
        private System.Windows.Forms.Button cour;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Button apt;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button ins;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button sta;
    }
}